<?php
$dbHost = 'Localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'bibliotec';

$conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);


?>
